import React from 'react'
import BasicExample from '../components/Navbar/Navbar'

const About = () => {
  return (
    <div>
    <BasicExample />
    <h1>ABOUT PAGE</h1>
    </div>
  )
}

export default About